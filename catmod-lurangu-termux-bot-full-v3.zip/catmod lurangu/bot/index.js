const fs=require("fs"),path=require("path");
const {Client,GatewayIntentBits}=require("discord.js");
const TOKEN=process.env.DISCORD_TOKEN;
const DEOB=path.join(__dirname,"..","deob.js");
const TMP=path.join(__dirname,"tmp");
if(!TOKEN) process.exit(console.error("❌ DISCORD_TOKEN chưa được cung cấp."),1);
if(!fs.existsSync(DEOB)) process.exit(console.error("❌ Không tìm thấy deob.js"),1);
fs.mkdirSync(TMP,{recursive:true});
const client=new Client({intents:[GatewayIntentBits.Guilds,GatewayIntentBits.GuildMessages,GatewayIntentBits.MessageContent]});
client.once("ready",()=>console.log(`✅ Bot online: ${client.user.tag}`));
client.on("messageCreate",async m=>{
 if(m.author.bot)return;
 const a=m.attachments.find(x=>/\.(lua|luau)$/i.test(x.name||""));
 if(!a)return;
 const id=`${Date.now()}-${process.pid}`, input=path.join(TMP,`${id}-${path.basename(a.name)}`), ext=path.extname(a.name)||".lua", output=path.join(TMP,`${id}-deob${ext}`);
 try{
  await m.reply("⏳ Đang deobfuscate...");
  const r=await fetch(a.url); if(!r.ok) throw Error(`HTTP ${r.status}`);
  fs.writeFileSync(input,Buffer.from(await r.arrayBuffer()));
  const {spawn}=require("child_process"), p=spawn(process.execPath,[DEOB,input,"-o",output],{cwd:path.dirname(DEOB)});
  let out="",err=""; p.stdout?.on("data",d=>out+=d); p.stderr?.on("data",d=>err+=d);
  const code=await new Promise(res=>{p.on("error",e=>{err+=e;res(-1)});p.on("close",res)});
  if(code!==0||!fs.existsSync(output)) throw Error((err||out||"Không tạo được output").slice(-1800));
  await m.reply({content:"✅ Deob xong.",files:[{attachment:output,name:`deob_${path.basename(a.name)}`}]});
 }catch(e){await m.reply(`❌ Deob thất bại.\n\`\`\`\n${String(e).slice(0,1800)}\n\`\`\``)}
 finally{for(const p of [input,output])try{if(fs.existsSync(p))fs.unlinkSync(p)}catch{}}
});
client.login(TOKEN).catch(e=>{console.error("❌ Discord login thất bại:",e.message);process.exit(1)});
