# Catmod Lurangu + Discord Bot (Termux)

LẦN ĐẦU:
```bash
cd ~/catmod-lurangu-bot
chmod +x install-termux.sh start-bot.sh deob.sh
./install-termux.sh
```

Installer tự cài package, Node/npm, CMake/Ninja/Clang/LLD, build Luau + luau-ast, chép binary vào Catmod và `npm install` cho bot. Nếu `~/luau/build/luau` đã build thành công thì tái sử dụng.

SAU KHI CÀI:
```bash
cd ~/catmod-lurangu-bot
./start-bot.sh
```
Script hỏi token, token được nhập ẩn và không ghi vào file.

Nếu installer dừng do lỗi build, gửi phần cuối lỗi; không cần cài lại từ đầu nếu `~/luau/build/luau` đã tồn tại.
