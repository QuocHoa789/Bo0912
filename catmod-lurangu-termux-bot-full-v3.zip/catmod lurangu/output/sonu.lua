local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")
local playerGui = Players.LocalPlayer:WaitForChild("PlayerGui")
local mirandaHubUpdate = playerGui:FindFirstChild("MirandaHubUpdate")

if mirandaHubUpdate then
	mirandaHubUpdate:Destroy()
end

local screenGui = Instance.new("ScreenGui", playerGui)
screenGui.Name = "MirandaHubUpdate"
screenGui.ResetOnSpawn = false
screenGui.DisplayOrder = 9999
local frame = Instance.new("Frame", screenGui)
frame.Name = "UpdateCard"
frame.AnchorPoint = Vector2.new(0.5, 0.5)
frame.Position = UDim2.fromScale(0.5, 0.5)
frame.Size = UDim2.fromOffset(390, 218)
frame.BackgroundColor3 = Color3.fromRGB(9, 9, 12)
frame.BorderSizePixel = 0
Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 16)
local uiStroke = Instance.new("UIStroke", frame)
uiStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
uiStroke.Color = Color3.fromRGB(230, 31, 43)
uiStroke.Thickness = 2.5
local uiScale = Instance.new("UIScale", frame)

local function fn()
	local currentCamera = Workspace.CurrentCamera

	if currentCamera then
		uiScale.Scale = math.clamp(currentCamera.ViewportSize.X / 440, 0.72, 1)
	end
end

fn()

if Workspace.CurrentCamera then
	Workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(fn)
end

local textLabel = Instance.new("TextLabel", frame)
textLabel.BackgroundTransparency = 1
textLabel.Position = UDim2.fromOffset(20, 18)
textLabel.Size = UDim2.new(1, -40, 0, 29)
textLabel.Font = Enum.Font.GothamBlack
textLabel.TextSize = 22
textLabel.RichText = true
textLabel.Text = "<font color=\"#F22F3D\">MIRANDA</font> <font color=\"#FFFFFF\">HUB</font>"
textLabel.TextXAlignment = Enum.TextXAlignment.Center
local textLabel2 = Instance.new("TextLabel", frame)
textLabel2.BackgroundTransparency = 1
textLabel2.Position = UDim2.fromOffset(20, 48)
textLabel2.Size = UDim2.new(1, -40, 0, 22)
textLabel2.Font = Enum.Font.GothamBold
textLabel2.TextSize = 14
textLabel2.TextColor3 = Color3.fromRGB(235, 235, 239)
textLabel2.Text = "UPDATE REQUIRED"
textLabel2.TextXAlignment = Enum.TextXAlignment.Center
local textLabel3 = Instance.new("TextLabel", frame)
textLabel3.BackgroundTransparency = 1
textLabel3.Position = UDim2.fromOffset(28, 76)
textLabel3.Size = UDim2.new(1, -56, 0, 38)
textLabel3.Font = Enum.Font.GothamMedium
textLabel3.TextSize = 11
textLabel3.TextColor3 = Color3.fromRGB(148, 148, 158)
textLabel3.TextWrapped = true
textLabel3.Text = "This version is no longer available. Join the official Discord to get the current Miranda Hub."
textLabel3.TextXAlignment = Enum.TextXAlignment.Center
local textLabel4 = Instance.new("TextLabel", frame)
textLabel4.Position = UDim2.fromOffset(24, 121)
textLabel4.Size = UDim2.new(1, -48, 0, 34)
textLabel4.BackgroundColor3 = Color3.fromRGB(18, 18, 23)
textLabel4.BorderSizePixel = 0
textLabel4.Font = Enum.Font.GothamBold
textLabel4.TextSize = 12
textLabel4.TextColor3 = Color3.fromRGB(225, 225, 232)
textLabel4.Text = "https://discord.gg/AKaEHZhuuU"
textLabel4.TextTruncate = Enum.TextTruncate.AtEnd
textLabel4.TextXAlignment = Enum.TextXAlignment.Center
Instance.new("UICorner", textLabel4).CornerRadius = UDim.new(0, 8)
local uiStroke2 = Instance.new("UIStroke", textLabel4)
uiStroke2.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
uiStroke2.Color = Color3.fromRGB(55, 55, 67)
uiStroke2.Transparency = 0.15
local textButton = Instance.new("TextButton", frame)
textButton.AnchorPoint = Vector2.new(0.5, 0)
textButton.Position = UDim2.new(0.5, 0, 0, 167)
textButton.Size = UDim2.fromOffset(174, 34)
textButton.BackgroundColor3 = Color3.fromRGB(65, 105, 225)
textButton.BorderSizePixel = 0
textButton.Font = Enum.Font.GothamBold
textButton.TextSize = 12
textButton.TextColor3 = Color3.new(1, 1, 1)
textButton.Text = "COPY DISCORD"
Instance.new("UICorner", textButton).CornerRadius = UDim.new(0, 9)

textButton.MouseButton1Click:Connect(function()
	local v = setclipboard or toclipboard

	if v and pcall(v, "https://discord.gg/AKaEHZhuuU") then
		textButton.Text = "COPIED!"
	else
		textButton.Text = "COPY NOT SUPPORTED"
	end

	task.delay(1.4, function()
		if textButton.Parent then
			textButton.Text = "COPY DISCORD"
		end
	end)
end)
