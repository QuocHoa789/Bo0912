repeat
	wait()
until game:IsLoaded()

local v = (getgenv or getrenv or getfenv)()
local kaitunFruit = v.KaitunFruit and typeof(v.KaitunFruit) == "table" and v.KaitunFruit or {}
kaitunFruit.Team = kaitunFruit.Team or "Marines"
kaitunFruit.BlacklistFruits = kaitunFruit.BlacklistFruits or {}
kaitunFruit.Webhook = kaitunFruit.Webhook or {}
kaitunFruit.Webhook.Enabled = kaitunFruit.Webhook.Enabled or false
kaitunFruit.Webhook.Url = kaitunFruit.Webhook.Url or ""
kaitunFruit.UsingHopApi = kaitunFruit.UsingHopApi or true
v.KaitunFruit = kaitunFruit

local scriptSource

if type(debug) == "table" and type(debug.info) == "function" then
	local ok, chunk = pcall(debug.info, 1, "s")
	scriptSource = ok and type(chunk) == "string" and chunk or nil
end

if not (scriptSource and scriptSource:find("KaitunFruit", 1, true)) then
	scriptSource = nil
end

if v.DaddyFindFruitRunning then
	return
end

v.DaddyFindFruitRunning = true

local obj = setmetatable({}, { __index = function(arg, arg2)
	return game:GetService(arg2)
end })

local workspace = obj.Workspace
local replicatedStorage = obj.ReplicatedStorage
local lighting = obj.Lighting
local httpService = obj.HttpService
local tweenService = obj.TweenService
local players = obj.Players
players = players and players.LocalPlayer

local function getCommF()
	local remotes = replicatedStorage:FindFirstChild("Remotes")
	return remotes and remotes:FindFirstChild("CommF_")
end

local function teleportToServer(jobId)
	local commF = getCommF()
	local serverBrowser = replicatedStorage:FindFirstChild("__ServerBrowser")

	if commF and commF:IsA("RemoteFunction") then
		return commF:InvokeServer("JoinOtherServer", jobId)
	end

	if serverBrowser and serverBrowser:IsA("RemoteFunction") then
		return serverBrowser:InvokeServer("teleport", jobId)
	end
end

local tbl = {
	["Store Fruit"] = true,
	Start = true,
	Servers = {},
	["Hop Delay"] = 1.5,
	["Bypass Teleport"] = true,
}

local tbl2 = {}
local tbl3 = { Module = {} }

tbl3.SetStatus = function(arg)
	pcall(function()
		tbl3.Features.Status["Script Status"]:SetDesc(arg)
	end)
end

tbl3.InitModules = function()
	local module = tbl3.Module

	for k, v2 in pairs(module) do
		if typeof(v2) == "function" then
			local ok, result = pcall(v2)

			if ok and result then
				module[k] = result
			elseif not ok and result then
				warn("Loader", "Module", "Failed to load", k, result)
			end
		end
	end
end

tbl3.InitSettings = function()
	local settings

	settings = {
		SaveSettings = function()
			writefile(players.Name .. "_FindFruitConfig.json", httpService:JSONEncode(tbl))
		end,
		LoadSettings = function()
			local ok, result = pcall(function()
				return httpService:JSONDecode(readfile(players.Name .. "_FindFruitConfig.json"))
			end)

			if not ok then
				settings.SaveSettings()
				return settings.LoadSettings()
			end
			return result
		end,
	}

	local v2 = tbl
	tbl = settings.LoadSettings()
	local flag = false

	for k, v3 in pairs(v2) do
		if tbl[k] == nil then
			tbl[k] = v3
			flag = true
		end
	end

	if flag then
		settings.SaveSettings()
	end

	setmetatable(tbl2, {
		__index = tbl,
		__newindex = function(arg, arg2, arg3)
			rawset(tbl, arg2, arg3 or nil)
			settings.SaveSettings()
		end,
	})

	tbl3.Module.Settings = settings
end

tbl3.Module.TweenModules = function()
	local TweenModules = {}

	TweenModules.TP = function(cFrame)
		local character = players and players.Character
		local hrp = character and character:FindFirstChild("HumanoidRootPart")

		if not hrp then
			return false
		end

		local speed = math.max(tonumber(tbl2["Tween Speed"]) or 300, 1)
		local distance = (cFrame.Position - hrp.Position).Magnitude

		if distance <= 0 then
			hrp.CFrame = cFrame
			return true
		end

		local tween = tweenService:Create(hrp, TweenInfo.new(math.clamp(distance / speed, 0.05, 30), Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { CFrame = cFrame })
		tween:Play()
		tween.Completed:Wait()
		return true
	end

	return TweenModules
end

tbl3.Module.PlayerMD = function()
	local PlayerMD = {}

	PlayerMD.GetCharacter = function()
		return players and players.Character
	end

	PlayerMD.GetHRP = function()
		local character = PlayerMD.GetCharacter()
		return character and character:FindFirstChild("HumanoidRootPart")
	end

	return PlayerMD
end

tbl3.Module.Encrypt = function()
	local Encrypt = {}

	Encrypt.decodeJobId = function(jobId)
		if type(jobId) ~= "string" then
			return nil
		end

		local encoded = jobId:gsub("^GameJobId_", ""):gsub("%-", "+"):gsub("_", "/")
		local padding = #encoded % 4

		if padding > 0 then
			encoded = encoded .. string.rep("=", 4 - padding)
		end

		local ok, decoded = pcall(function()
			return httpService:Base64Decode(encoded)
		end)

		if not ok or type(decoded) ~= "string" then
			return nil
		end

		return decoded:match("^([%w%-]+)")
	end

	return Encrypt
end

tbl3.Module.BypassTP = function()
	local BypassTP = {}
	local Runtime = { Bypassing = false, Count = 0 }

	BypassTP.Runtime = Runtime
	BypassTP.Distance = 2000

	function BypassTP.ResetCount()
		Runtime.Count = 0
	end

	function BypassTP.CanBypass()
		return tbl2["Bypass Teleport"] == true and Runtime.Count < 3
	end

	function BypassTP.GetBypassCFrame(position)
		if typeof(position) ~= "Vector3" then
			return nil
		end
		return CFrame.new(position)
	end

	function BypassTP.Start(position)
		if Runtime.Bypassing then
			return false
		end

		local character = players and players.Character
		local hrp = character and character:FindFirstChild("HumanoidRootPart")

		if not hrp then
			return false
		end

		Runtime.Bypassing = true
		Runtime.Count = Runtime.Count + 1

		task.spawn(function()
			pcall(function()
				local humanoid = character:FindFirstChildOfClass("Humanoid")

				if humanoid then
					humanoid.Sit = true
				end

				task.wait(0.1)
				hrp.CFrame = CFrame.new(position + Vector3.new(math.random(-20, 20), 3, math.random(-20, 20)))
				task.wait(0.15)
				hrp.CFrame = CFrame.new(position)
				task.wait(0.2)

				if humanoid then
					humanoid.Sit = false
				end
			end)

			Runtime.Bypassing = false
		end)

		return true
	end

	return BypassTP
end

tbl3.CreateWindow = function()
	tbl3.Library = loadstring(game:HttpGet("https://github.com/dawid-scripts/Fluent/releases/latest/download/main.lua"))()

	tbl3.Window = tbl3.Library:CreateWindow({
		Title = "Project Daddy Find Fruits",
		SubTitle = "Devs by @tthanh",
		TabWidth = 145,
		MinimizeKey = Enum.KeyCode.RightControl,
		Size = UDim2.fromOffset(450, 350),
		Acrylic = false,
		Theme = tbl2["Select Themes"],
		Image = "rbxassetid://",
	})
end

tbl3.CreateTabs = function()
	tbl3.Tabs = {}
	tbl3.Features = {}

	local function fn(arg, arg2)
		tbl3.Features[arg] = {}
		tbl3.Tabs[arg] = tbl3.Window:AddTab({ Title = arg, Icon = arg2 })
	end

	fn("Status", "home")
	fn("Configuration", "settings")
	tbl3.Window:SelectTab(1)
end

tbl3.LoadLibrary = function()
	tbl3.CreateWindow()
	tbl3.CreateTabs()

	local function fn(arg, arg2)
		if not arg2.Title then
			warn("Paragraph Missing Title!")
			return
		end
		tbl3.Features[arg][arg2.Title] = tbl3.Tabs[arg]:AddParagraph(arg2)
	end

	local function fn2(arg, arg2)
		if not arg2.Title or not arg2.Values then
			warn("Dropdown Missing Title or Values!")
			return
		end
		arg2.Default = arg2.Default or tbl2[arg2.Title] or arg2.Multi and {} or ""

		arg2.Callback = arg2.Callback or function(arg3)
			tbl2[arg2.Title] = arg3
		end

		return tbl3.Tabs[arg]:AddDropdown("Dropdown", arg2)
	end

	local function fn3(arg, arg2)
		if not arg2.Title then
			warn("Toggle Missing Title!")
			return
		end
		arg2.Default = arg2.Default or tbl2[arg2.Title] or false

		arg2.Callback = arg2.Callback or function(arg3)
			tbl2[arg2.Title] = arg3
		end

		return tbl3.Tabs[arg]:AddToggle("Toggle", arg2)
	end

	local function fn4(arg, arg2)
		if not arg2.Title then
			warn("Textbox Missing Title!")
			return
		end
		arg2.Default = arg2.Default or tbl2[arg2.Title] or false
		arg2.PlaceHolder = arg2.PlaceHolder or ""
		arg2.Numberic = arg2.Numberic or false

		arg2.Callback = arg2.Callback or function(arg3)
			tbl2[arg2.Title] = arg3
		end

		return tbl3.Tabs[arg]:AddInput("Textbox", arg2)
	end

	fn("Status", { Title = "Fruits In Server", Content = "Finding..." })
	fn("Status", { Title = "Time Elapsed", Content = "0 Hours 0 Minutes 0 Seconds" })
	fn("Status", { Title = "Script Status", Content = "None" })

	fn2("Configuration", {
		Title = "Select Themes",
		Values = { "Dark", "Darker", "Light", "Aqua", "Amethyst", "Rose" },
		Callback = function(arg)
			tbl3.Library:SetTheme(arg)
			tbl2["Select Themes"] = arg
		end,
	})

	fn2("Configuration", { Title = "Tween Speed", Values = { "180", "250", "300", "325", "350" }, Desc = "High=Risk" })
	fn3("Configuration", { Title = "Fix lag when executing script" })
	fn3("Configuration", { Title = "Bypass Teleport", Desc = "Respawn at nearest spawn instead of long tween" })
	fn4("Configuration", { Title = "Hop Delay", PlaceHolder = "Enter Number", Numberic = true })
	fn3("Configuration", { Title = "Start", Desc = "Start kaitun find Fruit" })
	fn3("Configuration", { Title = "Store Fruit" })
end

tbl3.MakeFunctions = function()
	tbl3.Functions = {}
	tbl3.Thread = {}

	local function fn(arg, arg2)
		if tbl2[arg] and not tbl3.Thread[arg] then
			tbl3.Thread[arg] = true

			spawn(function()
				while tbl2[arg] and wait() do
					local ok, result = pcall(arg2)

					if not ok then
						warn(arg, result)
					end
				end

				tbl3.Thread[arg] = nil
			end)
		end
	end

	local tweenModules = tbl3.Module.TweenModules
	local playerMD = tbl3.Module.PlayerMD
	local encrypt = tbl3.Module.Encrypt
	local bypassTP = tbl3.Module.BypassTP
	local n = 25

	local function fn2(cFrame)
		if bypassTP.Runtime and bypassTP.Runtime.Bypassing then
			return false
		end
		local v2 = playerMD.GetHRP()
		if not v2 then
			return false
		end
		local position = cFrame.Position
		local magnitude = (position - v2.Position).Magnitude

		if magnitude <= n then
			bypassTP.ResetCount()
			v2.CFrame = cFrame
			return true
		end

		if magnitude >= (bypassTP.Distance or math.huge) and bypassTP.CanBypass() and bypassTP.GetBypassCFrame(position) then
			return bypassTP.Start(position)
		end
		tweenModules.TP(cFrame, true)
		return true
	end

	local function fn3()
		local tbl4 = {}
		local v2 = next
		local children, v3 = workspace:GetChildren()

		for _, v4 in v2, children, v3 do
			if (v4:IsA("Model") or v4:IsA("Tool")) and string.find(v4.Name, "Fruit") and v4.Parent and v4:FindFirstChild("Handle") then
				table.insert(tbl4, v4)
			end
		end

		return tbl4
	end

	local n2 = 500
	local isHopping = false
	local scanFailures = 0
	local collected = {}

	local function isNewFruit(fruit)
		local name = fruit.Name

		if collected[name] then
			return false
		end

		collected[name] = true
		return true
	end

	local function rerunAfterHop()
		if not scriptSource then
			warn("HopFindFruit", "Cannot persist the script across teleports")
			return
		end

		if type(writefile) == "function" then
			pcall(writefile, "DaddyFindFruit.lua", scriptSource)
		end

		if type(queue_on_teleport) == "function" and type(readfile) == "function" then
			pcall(function()
				queue_on_teleport("DaddyFindFruitHop", function()
					local chunk = readfile("DaddyFindFruit.lua")

					if type(chunk) == "string" and chunk:find("KaitunFruit", 1, true) then
						loadstring(chunk)()
					end
				end)
			end)
		else
			warn("HopFindFruit", "queue_on_teleport unavailable, re-run the script after hopping")
		end
	end

	local function hopServer()
		if isHopping then
			return
		end

		local previousJobId = game.JobId
		isHopping = true
		pcall(function()
			tbl3.Library:Notify({
				Title = "Hop Find Fruit",
				Content = "No fruit server found, hopping to a new server.",
				Duration = 3,
			})
		end)
		v.DaddyFindFruitRunning = nil
		rerunAfterHop()

		task.spawn(function()
			task.wait(15)

			if isHopping and game.JobId == previousJobId then
				warn("HopFindFruit", "Teleport failed, resuming the search")
				isHopping = false
				scanFailures = 0
			end
		end)

		local teleportService = obj.TeleportService
		local ok = pcall(function()
			teleportService:TeleportToPlaceInstance(game.PlaceId, game.PlaceId, game.JobId)
		end)

		if not ok then
			pcall(function()
				teleportService:Teleport(game.PlaceId)
			end)
		end
	end

	local function fn4(arg)
		if typeof(tbl2.Servers) ~= "table" then
			tbl2.Servers = {}
		end

		local servers = tbl2.Servers
		local flag = false

		if not table.find(servers, arg) then
			table.insert(servers, arg)
			flag = true
		end

		while n2 < #servers do
			table.remove(servers, 1)
			flag = true
		end

		if flag then
			tbl3.Module.Settings.SaveSettings()
		end

		return servers
	end

	local function fn5()
		local v2 = fn4(game.JobId)
		local tbl4 = {}

		for _, v3 in ipairs(v2) do
			tbl4[v3] = true
		end

		local ok, result = pcall(function()
			if type(http) == "table" and type(http.request) == "function" then
				return http.request({ Url = "http://163.223.9.144/boss/Fruits", Method = "GET" })
			end
			return { Body = game:HttpGet("http://163.223.9.144/boss/Fruits"), StatusCode = 200 }
		end)

		if not ok or typeof(result) ~= "table" or not result.Body then
			warn("HopFindFruit", ok, typeof(result) == "table" and result.StatusCode or result)
			scanFailures = scanFailures + 1

			if scanFailures >= 3 then
				hopServer()
			end

			return
		end

		local ok2, result2 = pcall(function()
			return httpService:JSONDecode(result.Body)
		end)

		if not ok2 or typeof(result2) ~= "table" or typeof(result2.data) ~= "table" then
			warn("HopFindFruit", "Invalid response", result2)
			scanFailures = scanFailures + 1

			if scanFailures >= 3 then
				hopServer()
			end

			return
		end
		scanFailures = 0
		local tbl5 = {}
		local tbl6 = {}

		for _, v3 in pairs(result2.data) do
			if typeof(v3) == "table" and v3.JobId and v3.Age and v3.PlaceId == game.PlaceId then
				local v4 = encrypt.decodeJobId(v3.JobId)

				if v4 and v4 ~= game.JobId and not tbl5[v4] and not tbl4[v4] and not table.find(v.KaitunFruit.BlacklistFruits, v3.Name) then
					tbl5[v4] = true
					table.insert(tbl6, { JobId = v4, Name = v3.Name, Age = v3.Age })
				end
			end
		end

		if #tbl6 <= 0 then
			hopServer()
			return
		end

		table.sort(tbl6, function(arg, arg2)
			return arg.Age < arg2.Age
		end)

		for _, v3 in ipairs(tbl6) do
			local jobId = v3.JobId

			tbl3.Library:Notify({
				Title = "Joining Server Have Fruit",
				Content = "Fruit Name: " .. tostring(v3.Name) .. " JobId: " .. jobId .. " Age: " .. tostring(v3.Age),
				Duration = 3,
			})

			teleportToServer(v3.JobId)
			task.wait(0.3)
		end
	end

	local function fn6()
		local serverBrowser = replicatedStorage:WaitForChild("__ServerBrowser", 10)

		if not serverBrowser or not serverBrowser:IsA("RemoteFunction") then
			return
		end

		for i = 1, 100 do
			for k, v2 in next, serverBrowser:InvokeServer(i), nil do
				if game.JobId ~= k and v2.Count <= 12 then
					serverBrowser:InvokeServer("teleport", k)
					task.wait(0.3)
				end
			end
		end
	end

	tbl3.Functions["Fix lag when executing script"] = function()
		if v.KaitunFruit.FixedLag then
			return
		end
		v.KaitunFruit.FixedLag = true

		pcall(function()
			for _, descendant in pairs(lighting:GetDescendants()) do
				if descendant:IsA("Atmosphere") then
					descendant:Destroy()
				end
			end

			local terrain = workspace:FindFirstChildOfClass("Terrain")

			if terrain then
				terrain.WaterWaveSize = 0
				terrain.WaterWaveSpeed = 0
				terrain.WaterReflectance = 0
				terrain.WaterTransparency = 1
			end

			lighting.GlobalShadows = false
			lighting.FogStart = 9e9
			lighting.FogEnd = 9e9

			for _, descendant in ipairs(lighting:GetDescendants()) do
				if descendant:IsA("PostEffect") then
					descendant.Enabled = false
				end
			end

			local UserGameSettings = UserSettings():GetService("UserGameSettings")
			UserGameSettings.SavedQualityLevel = Enum.SavedQualitySetting.QualityLevel1
			UserGameSettings.MasterVolume = 0

			if sethiddenproperty then
				sethiddenproperty(UserGameSettings, "GraphicsQualityLevel", 1)
			end

			SoundService.Volume = 0
		end)

		local function fn7(arg)
			if arg:IsA("BasePart") then
				arg.CastShadow = false
				arg.Material = Enum.Material.Plastic
				arg.Reflectance = 0
			elseif arg:IsA("Decal") then
				arg.Texture = ""
				arg.Transparency = 1
			elseif arg:IsA("ParticleEmitter") then
				arg.Lifetime = NumberRange.new(0)
			elseif arg:IsA("Trail") then
				arg.Lifetime = 0
			elseif arg:IsA("ForceField") or arg:IsA("Sparkles") or arg:IsA("Smoke") or arg:IsA("Fire") or arg:IsA("Beam") then
				task.defer(function()
					pcall(function()
						arg:Destroy()
					end)
				end)
			end
		end

		for i, descendant in ipairs(workspace:GetDescendants()) do
			pcall(fn7, descendant)

			if i % 5000 == 0 then
				task.wait()
			end
		end

		wait(1)
	end

	tbl3.Functions["Store Fruit"] = function()
		local character = players.Character
		local backpack = players:FindFirstChild("Backpack")

		if not character or not backpack then
			return
		end

		local commF = getCommF()

		if not commF or not commF:IsA("RemoteFunction") then
			return
		end

		for _, child in pairs(character:GetChildren()) do
			if child.Name:find("Fruit") and child:GetAttribute("OriginalName") then
				commF:InvokeServer("StoreFruit", child:GetAttribute("OriginalName"), child)
				task.wait(0.1)
			end
		end

		for _, child in pairs(backpack:GetChildren()) do
			if child.Name:find("Fruit") and child:GetAttribute("OriginalName") then
				commF:InvokeServer("StoreFruit", child:GetAttribute("OriginalName"), child)
				task.wait(0.1)
			end
		end
	end

	tbl3.Functions.Start = function()
		if isHopping then
			return
		end
		if bypassTP.Runtime and bypassTP.Runtime.Bypassing then
			return
		end
		local v2 = fn3()
		local v3 = playerMD.GetHRP()

		if not v3 then
			return
		end

		for i = #v2, 1, -1 do
			if not isNewFruit(v2[i]) then
				table.remove(v2, i)
			end
		end

		if #v2 > 0 then
			local v4 = v2[1]
			local handle = v4 and v4:FindFirstChild("Handle")

			if not handle then
				return
			end

			if type(firetouchinterest) == "function" then
				firetouchinterest(handle, v3, true)
				task.wait(0.1)
				firetouchinterest(handle, v3, false)
			else
				fn2(handle.CFrame)
			end
		else
			task.wait(tonumber(tbl2["Hop Delay"]) or 1.5)

			if v.KaitunFruit.UsingHopApi then
				fn5()
			else
				fn6()
			end
		end
	end

	spawn(function()
		while wait() do
			for k, v2 in next, tbl3.Functions, nil do
				fn(k, v2)
			end
		end
	end)

	spawn(function()
		while wait() do
			local v2 = fn3()

			if #v2 > 0 then
				for k, v3 in pairs(v2) do
					v2[k] = v3.Name
				end

				tbl3.Features.Status["Fruits In Server"]:SetDesc(table.concat(v2, ", "))
			else
				tbl3.Features.Status["Fruits In Server"]:SetDesc("No Fruit Found.")
			end
		end
	end)
end

tbl3.Authenticate = function()
	tbl3.SetStatus("Authenticated")
end

tbl3.JoinTeam = function()
	local commF = getCommF()

	if not commF or not commF:IsA("RemoteFunction") then
		return
	end

	if players.Team == nil then
		commF:InvokeServer("SetTeam", v.KaitunFruit.Team)
	end
end

tbl3.Authenticate()
tbl3.JoinTeam()
tbl3.InitModules()
tbl3.InitSettings()
tbl3.LoadLibrary()
tbl3.MakeFunctions()
