#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; BOT="$ROOT/bot"
if [ ! -d "$BOT/node_modules/discord.js" ]; then echo "==> discord.js chưa có, tự cài..."; cd "$BOT"; npm install --omit=dev; fi
if [ ! -x "$ROOT/catmod-lurangu/bin/luau" ] || [ ! -x "$ROOT/catmod-lurangu/bin/luau-ast" ]; then
 echo "❌ Luau chưa cài. Chạy ./install-termux.sh trước."; exit 1
fi
printf "🔑 Nhập Discord Bot Token: "; IFS= read -r -s TOKEN; echo
[ -n "$TOKEN" ] || { echo "❌ Token trống."; exit 1; }
export DISCORD_TOKEN="$TOKEN"; unset TOKEN
cd "$BOT"; exec npm start
