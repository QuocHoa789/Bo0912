#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; CATMOD="$ROOT/catmod-lurangu"; BIN="$CATMOD/bin"; LUAU="$HOME/luau"
trap 'echo; echo "❌ Cài đặt dừng ở dòng $LINENO."; exit 1' ERR
echo "==> Cài package Termux"
pkg update -y
pkg upgrade -y
pkg install -y git python nodejs npm cmake ninja clang lld libc++ make unzip
echo "==> Node: $(node -v)"
mkdir -p "$BIN"
if [ ! -d "$LUAU/.git" ]; then rm -rf "$LUAU"; git clone --depth 1 https://github.com/luau-lang/luau.git "$LUAU"; fi
cd "$LUAU"
if [ ! -x build/luau ]; then
 rm -rf build
 cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DLUAU_BUILD_TESTS=OFF -DLUAU_BUILD_WEB=OFF -DCMAKE_CXX_FLAGS="-stdlib=libc++" -DCMAKE_EXE_LINKER_FLAGS="-stdlib=libc++"
 cmake --build build --target Luau.Repl.CLI -j2
fi
if [ ! -x build/luau-ast ]; then cmake --build build --target Luau.Ast.CLI -j2; fi
test -x build/luau && test -x build/luau-ast
cp -f build/luau "$BIN/luau"; cp -f build/luau-ast "$BIN/luau-ast"; chmod +x "$BIN/luau" "$BIN/luau-ast"
echo "==> Kiểm tra Catmod"
"$BIN/luau" -v; cd "$CATMOD"; node --check deob.js
echo "==> Cài Discord bot"
cd "$ROOT/bot"; npm install --omit=dev
echo; echo "✅ CÀI ĐẶT HOÀN TẤT"; echo "Chạy: cd \"$ROOT\" && ./start-bot.sh"
