#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
CATMOD="$ROOT/catmod-lurangu"
BIN="$CATMOD/bin"
LUau="$HOME/luau"
export PATH="$HOME/bin:$PATH"

echo "== Catmod Lurangu + Discord Bot / Termux setup =="

pkg update -y
pkg install -y git python nodejs npm cmake ninja clang make unzip

mkdir -p "$BIN"

if [ ! -x "$LUau/build/luau" ]; then
  echo "[1/5] Building Luau..."
  if [ ! -d "$LUau/.git" ]; then
    rm -rf "$LUau"
    git clone --depth 1 https://github.com/luau-lang/luau.git "$LUau"
  fi
  cd "$LUau"
  cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
  cmake --build build --target Luau.Repl.CLI -j"$(nproc)"
  cmake --build build --target Luau.Ast.CLI -j"$(nproc)"
else
  echo "[1/5] Luau already built."
fi

if [ ! -x "$BIN/luau" ]; then cp "$LUau/build/luau" "$BIN/luau"; fi
if [ ! -x "$BIN/luau-ast" ]; then
  if [ -f "$LUau/build/luau-ast" ]; then cp "$LUau/build/luau-ast" "$BIN/luau-ast"
  else
    echo "❌ Không tìm thấy build/luau-ast"; exit 1
  fi
fi
chmod +x "$BIN/luau" "$BIN/luau-ast"

echo "[2/5] Testing Luau..."
"$BIN/luau" -v
"$BIN/luau-ast" --help >/dev/null 2>&1 || true

echo "[3/5] Installing bot dependencies..."
cd "$ROOT/bot"
npm install --omit=dev

echo "[4/5] Checking Catmod..."
cd "$CATMOD"
node --check deob.js

echo "[5/5] Done."
echo
echo "Deob trực tiếp:  bash \"$ROOT/deob.sh\" file.lua"
echo "Chạy bot:        bash \"$ROOT/start-bot.sh\""
