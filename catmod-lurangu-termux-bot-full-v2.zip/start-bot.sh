#!/data/data/com.termux/files/usr/bin/bash
set -e

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT/bot"

printf "🔑 Nhập Discord Bot Token: "
read -r -s TOKEN
echo

if [ -z "$TOKEN" ]; then
  echo "❌ Token không được để trống."
  exit 1
fi

export DISCORD_TOKEN="$TOKEN"
exec npm start
