const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");
const { Client, GatewayIntentBits, AttachmentBuilder } = require("discord.js");

const TOKEN = process.env.DISCORD_TOKEN;
const DEOB = path.join(__dirname, "..", "catmod-lurangu", "deob.js");
const TMP = path.join(__dirname, "tmp");

if (!TOKEN) {
  console.error("❌ DISCORD_TOKEN chưa được đặt.");
  console.error("Chạy: export DISCORD_TOKEN='TOKEN_CUA_BAN'");
  process.exit(1);
}
if (!fs.existsSync(DEOB)) {
  console.error("❌ Không tìm thấy Catmod:", DEOB);
  process.exit(1);
}
fs.mkdirSync(TMP, { recursive: true });

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.once("ready", () => console.log(`✅ Bot online: ${client.user.tag}`));

client.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  const attachment = message.attachments.first();
  if (!attachment) return;

  const ext = path.extname(attachment.name).toLowerCase();
  if (![".lua", ".luau"].includes(ext)) return;

  const id = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const input = path.join(TMP, `${id}${ext}`);
  const output = path.join(TMP, `${id}_deob.luau`);

  try {
    await message.reply("⏳ Đang deob...");
    const response = await fetch(attachment.url);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    fs.writeFileSync(input, Buffer.from(await response.arrayBuffer()));

    const child = spawn(process.execPath, [DEOB, input, "-o", output], {
      cwd: path.dirname(DEOB),
      stdio: ["ignore", "pipe", "pipe"]
    });

    let logs = "";
    child.stdout.on("data", d => logs += d.toString());
    child.stderr.on("data", d => logs += d.toString());

    const code = await new Promise(resolve => child.on("close", resolve));

    if (code !== 0 || !fs.existsSync(output)) {
      console.error(logs);
      await message.reply("❌ Deob thất bại.\n```text\n" + logs.slice(-1800) + "\n```");
      return;
    }

    const file = new AttachmentBuilder(output, {
      name: `${path.basename(attachment.name, ext)}_deob.luau`
    });
    await message.reply({ content: "✅ Deob xong!", files: [file] });
  } catch (err) {
    console.error(err);
    await message.reply("❌ Không thể xử lý file.");
  } finally {
    for (const f of [input, output]) {
      try { if (fs.existsSync(f)) fs.unlinkSync(f); } catch {}
    }
  }
});

client.login(TOKEN);
