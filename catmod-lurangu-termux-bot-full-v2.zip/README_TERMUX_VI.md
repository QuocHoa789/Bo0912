# Catmod Lurangu + Discord Bot — Termux

## 1) ZIP đơn lẻ (file này nằm thẳng trong Download)

Đặt `catmod-lurangu-termux-bot.zip` vào `Download`, rồi:

```bash
termux-setup-storage
cd ~/storage/downloads
unzip -q catmod-lurangu-termux-bot.zip -d ~/catmod-lurangu-bot
cd ~/catmod-lurangu-bot
bash install-termux.sh
```

Cài xong, deob trực tiếp:

```bash
bash ./deob.sh /đường/dẫn/file.lua
```

Kết quả nằm trong thư mục `output/` cạnh file input (theo hành vi của Catmod), hoặc theo `-o`.

Chạy Discord bot:

```bash
export DISCORD_TOKEN='TOKEN_CUA_BAN'
bash ./start-bot.sh
```

Lần sau chỉ cần:

```bash
cd ~/catmod-lurangu-bot
export DISCORD_TOKEN='TOKEN_CUA_BAN'
bash ./start-bot.sh
```

## 2) ZIP chồng ZIP (ví dụ Download/ccc-main/ccc-main/catmod_lurangu.zip)

Nếu ZIP ngoài chứa ZIP Catmod bên trong, KHÔNG chạy npm/node từ thư mục ngoài.

Ví dụ:

```text
Download/
└── ccc-main/
    └── ccc-main/
        └── catmod_lurangu.zip
```

Lấy ZIP trong ra rồi giải nén vào HOME:

```bash
cd ~/storage/downloads
mkdir -p ~/catmod-lurangu-bot
unzip -q ccc-main/ccc-main/catmod_lurangu.zip -d ~/catmod-lurangu-bot/catmod-lurangu
```

Sau đó đặt source bot + 3 script của gói này vào `~/catmod-lurangu-bot/`, sao cho cấu trúc là:

```text
~/catmod-lurangu-bot/
├── catmod-lurangu/
├── bot/
├── install-termux.sh
├── deob.sh
└── start-bot.sh
```

Rồi:

```bash
cd ~/catmod-lurangu-bot
bash install-termux.sh
```

## Vì sao phải copy vào HOME?

Android thường không cho thực thi binary native trực tiếp từ `/storage/emulated/0/Download`.
Nếu để `luau`/`luau-ast` ở Download, Node/Python có thể báo:

`EACCES`

Gói này build Luau ARM64 rồi đặt binary vào:

```text
~/catmod-lurangu-bot/catmod-lurangu/bin/
```

nên không cần chạy `.exe` Windows.

## Discord bot

Trong Discord Developer Portal, tạo bot, bật **Message Content Intent**, mời bot vào server với quyền cần thiết để đọc/gửi tin nhắn và đính kèm file.

Không ghi token vào `index.js`. Dùng:

```bash
export DISCORD_TOKEN='TOKEN_CUA_BAN'
bash ./start-bot.sh
```

Bot nhận `.lua` hoặc `.luau`, chạy Catmod và trả file deob.

## Nếu bot báo lỗi

Kiểm tra binary:

```bash
ls -l ~/catmod-lurangu-bot/catmod-lurangu/bin/
~/catmod-lurangu-bot/catmod-lurangu/bin/luau -v
~/catmod-lurangu-bot/catmod-lurangu/bin/luau-ast --help
```

Kiểm tra Node:

```bash
node -v
```

Kiểm tra source:

```bash
cd ~/catmod-lurangu-bot/catmod-lurangu
node --check deob.js
```

Nếu gặp lỗi mới, gửi nguyên khối lỗi từ Termux; đừng tự đổi đường dẫn `bin` sang `/storage/emulated/0`.
