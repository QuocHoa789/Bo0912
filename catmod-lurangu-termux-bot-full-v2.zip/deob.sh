#!/data/data/com.termux/files/usr/bin/bash
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
if [ "$#" -lt 1 ]; then
  echo "Dùng: bash ./deob.sh file.lua [file2.lua ...]"
  exit 2
fi
cd "$ROOT/catmod-lurangu"
exec node deob.js "$@"
